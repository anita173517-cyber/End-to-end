# RAM PLAYER v22.0 ULTIMATE — Engine Comparison, Architecture & Changelog Report

## 1. Playback Engine Technical Comparison (Part 2)

| Criterion | VideoLAN LibVLC 3.6.5 (SELECTED for VOD) | AndroidX Media3 1.11.1 (KEPT for Live TV) | MPV / libmpv |
| :--- | :--- | :--- | :--- |
| **Xtream VOD (MKV/MP4/AVI/TS/FLV/HLS)** | Excellent — plays virtually every container/codec out of the box | Good for HLS/MP4; fails on some MKV/AVI/DTS/AC3 TV boxes | Excellent, but requires custom NDK builds |
| **Audio Codecs (AC3/E-AC3/DTS/TrueHD/AAC/MP2)** | Built-in FFmpeg/avcodec decoding on all TVs | Relies heavily on device MediaCodec hardware | Built-in FFmpeg |
| **HW + SW Decoder Fallback** | Native `setHWDecoderEnabled(hw, force)` + automatic SW fallback | Hardware-first; limited SW audio/video codecs without FFmpeg ext | Supported, higher CPU on 512MB TVs |
| **±Audio & ±Subtitle Delay** | Native positive AND negative `audioDelay` & `spuDelay` (microseconds) | No native negative audio delay or subtitle offset | Supported |
| **Cinema Dialogue Boost / Equalizer** | Native 10-band `MediaPlayer.Equalizer` + safe 0–150% gain | External `LoudnessEnhancer` only (device-dependent) | Supported via af filters |
| **External Subtitles (SRT/ASS/VTT)** | Native `addSlave(IMedia.Slave.Type.Subtitle, uri, true)` | Requires MediaItem rebuild | Supported |
| **Network Buffering Cushion** | Configurable `--network-caching` (2.5s / 5.0s / 10.0s) + `--http-reconnect` | Configurable `DefaultLoadControl` | Supported |
| **Android Gradle / Maven Stability** | Official Maven Central `org.videolan.android:libvlc-all:3.6.5` (LGPL 2.1, 16KB page support) | Official Google Maven (`androidx.media3`) | No official Maven Central AAR |
| **APK Size Impact** | Adds ~35–45MB multi-ABI native libs (well suited for Android TV) | Compact (~3–4MB) | Large custom native `.so` bundle |

**Engineering Decision**: **LibVLC 3.6.5** is integrated as the genuine primary VOD engine (`LibVlcVodPlayerEngine` behind `VodPlayerEngine`) for Movies & Series, while **Media3 1.11.1** remains 100% untouched for Live TV fast zapping.

## 2. What Changed in RAM PLAYER v22.0 Ultimate
- **Genuine Engine Replacement**: Replaced ExoPlayer inside `VodPlayerActivity` with `LibVlcVodPlayerEngine` (`org.videolan.android:libvlc-all:3.6.5`) and `org.videolan.libvlc.util.VLCVideoLayout`.
- **Completely Rebuilt Deep-Charcoal Cinematic UI**: Removed oversized 3D glass bars and poster-based loading cards from `activity_vod_player.xml`. New minimal OTT interface features subtle top/bottom scrims, crisp center transport trio (`↺ 10s | ⏸/▶ | 10s ↻`), slim white buffered timeline with elapsed + remaining (`-MM:SS`) + total duration, high-contrast TV white focus pills, and clean modal sheets (`Audio`, `Subtitles`, `Video`, `Speed`, `Cinema Tools`, `Settings`).
- **Next-Gen Audio & Subtitle Systems**: `VodAudioController` (track discovery, preferred language auto-select, ±5000ms Audio Sync, 10-band LibVLC Equalizer Dialogue/Voice Clarity/Night Whisper presets, TV remote Volume Up/Down/Mute feedback) + native ±5000ms Subtitle Sync & external subtitle slave support.
- **Intelligent Buffering & Recovery**: `VodBufferingAndRecoveryController` distinguishes initial loading vs. mid-playback rebuffering (keeps video visible), auto-falls back from Hardware to Software decoder on decode error, and enforces bounded retries (max 3 transient, 0 for 401/403/404/410).
- **Live TV 100% Untouched**: Zero changes to Live TV playback engine, `media3PlayerView`, channel zapping, EPG, M3U parser, Xtream Live TV, or Live TV background playback.

## 3. Build & Verification Report
- `python3 scripts/verify_project.py`: **PASS** (verified v22.0 versionCode 220, `libvlc-all:3.6.5`, `VLCVideoLayout`, all XML resources, `R.*` IDs, `nextFocus` chains, zero duplicate imports, and Live TV invariants).
- **Offline Sandbox Note**: Local VM has OpenJDK 17 and Python 3 without Gradle/Android SDK/internet, so full `gradle testDebugUnitTest assembleDebug assembleRelease` must be run in GitHub Actions or Android Studio (never claiming physical TV testing that did not occur here).
