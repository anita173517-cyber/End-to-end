package com.harindra.iptvpro

import java.util.Locale

/**
 * Clear 7-state playback outcome for every Live TV channel.
 */
enum class ChannelPlaybackResult(val osdPrefix: String) {
    PLAYING("🟢 Live"),
    CONNECTING("⚡ Connecting"),
    BUFFERING("⏳ Buffering"),
    SWITCHING_ENGINE("⚡ Switching Engine"),
    SERVER_ERROR("⚠️ Server Error"),
    UNSUPPORTED("⚠️ Unsupported Format"),
    UNAVAILABLE("⚠️ Stream Unavailable")
}

enum class ErrorRecoveryAction {
    NONE_STOP,
    RETRY_WITH_COOLDOWN,
    SWITCH_ENGINE_ONCE,
    TRY_BACKUP_URL_ONCE
}

enum class CommittedRecoveryType {
    RETRY,
    ENGINE_SWITCH,
    BACKUP_URL,
    WATCHDOG_HEAL
}

/**
 * Authoritative recovery lifecycle state machine for a single Live TV playback session.
 * Prevents illegal transitions, concurrent double-recovery, and post-exhaustion restart loops.
 */
enum class RecoveryLifecycleState {
    SESSION_CREATED,
    PRIMARY_STARTED,
    PLAYBACK_PREPARED,
    PLAYBACK_CONFIRMED,
    ERROR_CLASSIFIED,
    RECOVERY_SELECTED,
    RECOVERY_COMMITTED,
    RECOVERY_SUCCESSFUL,
    RECOVERY_EXHAUSTED,
    USER_RETRY_REQUESTED,
    SESSION_CANCELLED
}

data class StreamErrorDecision(
    val result: ChannelPlaybackResult,
    val action: ErrorRecoveryAction,
    val maxRetries: Int,
    val cooldownMs: Long,
    val userMessage: String,
    val errorFingerprint: String
)

/**
 * RAM PLAYER v23.7 — Single Authoritative Bounded Recovery Controller & State Machine.
 *
 * Guarantees:
 * - Pure read-only evaluation (`evaluateDecision` NEVER mutates attempt counters).
 * - Exactly-once committed counting (`commitRecoveryAction` uses idempotent `actionId` + cooldown + hard cap of 3).
 * - Strict backup URL idempotency (`markBackupUrlTried` normalizes URLs and never double-counts or repeats a backup).
 * - Preserved across primary URL, backup URL, engine switch, and internal player recreation.
 * - Reset ONLY when the user selects a new channel or deliberately triggers a fresh playback session.
 */
class BoundedRecoverySession(
    val sessionToken: Long,
    val channelKey: String
) {
    companion object {
        const val MAX_TOTAL_RECOVERY_ATTEMPTS = 3
        const val MAX_ENGINE_SWITCHES = 1
        const val MAX_WATCHDOG_INTERVENTIONS = 1
        const val DEFAULT_RECOVERY_COOLDOWN_MS = 2000L

        fun normalizeUrlKey(raw: String?): String {
            return raw?.trim().orEmpty()
        }

        fun isValidHttpOrStreamUrl(raw: String?): Boolean {
            val clean = normalizeUrlKey(raw)
            if (clean.length < 8) return false
            val lower = clean.lowercase(Locale.ROOT)
            return lower.startsWith("http://") ||
                lower.startsWith("https://") ||
                lower.startsWith("rtmp://") ||
                lower.startsWith("rtmps://") ||
                lower.startsWith("rtsp://") ||
                lower.startsWith("udp://") ||
                lower.startsWith("mms://")
        }
    }

    var state: RecoveryLifecycleState = RecoveryLifecycleState.SESSION_CREATED
        private set
    var retryCount: Int = 0
        private set
    var totalRecoveryAttempts: Int = 0
        private set
    var engineSwitchCount: Int = 0
        private set
    var watchdogInterventions: Int = 0
        private set
    var backupUrlTried: Boolean = false
        private set
    var rebufferEvents: Int = 0
        private set

    private val attemptedUrls: LinkedHashSet<String> = LinkedHashSet(4)
    private val attemptedBackupUrls: LinkedHashSet<String> = LinkedHashSet(4)
    private val committedActionIds: LinkedHashSet<String> = LinkedHashSet(8)
    private var lastErrorFingerprint: String = ""
    private var consecutiveSameErrorCount: Int = 0
    private var lastRecoveryCommitMs: Long = 0L

    fun isCancelled(): Boolean = state == RecoveryLifecycleState.SESSION_CANCELLED

    fun isExhausted(): Boolean = state == RecoveryLifecycleState.RECOVERY_EXHAUSTED ||
        totalRecoveryAttempts >= MAX_TOTAL_RECOVERY_ATTEMPTS

    fun canTriggerWatchdog(nowElapsedMs: Long = 0L, minCooldownMs: Long = DEFAULT_RECOVERY_COOLDOWN_MS): Boolean {
        if (isCancelled() || isExhausted()) return false
        if (state == RecoveryLifecycleState.PLAYBACK_CONFIRMED || state == RecoveryLifecycleState.RECOVERY_SUCCESSFUL) return false
        if (watchdogInterventions >= MAX_WATCHDOG_INTERVENTIONS) return false
        if (nowElapsedMs > 0L && lastRecoveryCommitMs > 0L && (nowElapsedMs - lastRecoveryCommitMs) < minCooldownMs) {
            return false
        }
        return true
    }

    fun transitionTo(next: RecoveryLifecycleState): Boolean {
        if (state == next) return true
        // Cancelled session is strictly terminal
        if (state == RecoveryLifecycleState.SESSION_CANCELLED) return false
        // Exhausted session may only leave via USER_RETRY_REQUESTED or SESSION_CANCELLED
        if (state == RecoveryLifecycleState.RECOVERY_EXHAUSTED &&
            next != RecoveryLifecycleState.USER_RETRY_REQUESTED &&
            next != RecoveryLifecycleState.SESSION_CANCELLED
        ) {
            return false
        }
        val allowed = when (next) {
            RecoveryLifecycleState.SESSION_CREATED -> false
            RecoveryLifecycleState.PRIMARY_STARTED ->
                state == RecoveryLifecycleState.SESSION_CREATED || state == RecoveryLifecycleState.USER_RETRY_REQUESTED
            RecoveryLifecycleState.PLAYBACK_PREPARED ->
                state == RecoveryLifecycleState.PRIMARY_STARTED || state == RecoveryLifecycleState.RECOVERY_COMMITTED
            RecoveryLifecycleState.PLAYBACK_CONFIRMED ->
                state == RecoveryLifecycleState.PRIMARY_STARTED ||
                    state == RecoveryLifecycleState.PLAYBACK_PREPARED ||
                    state == RecoveryLifecycleState.RECOVERY_COMMITTED ||
                    state == RecoveryLifecycleState.RECOVERY_SUCCESSFUL
            RecoveryLifecycleState.ERROR_CLASSIFIED ->
                state != RecoveryLifecycleState.RECOVERY_EXHAUSTED
            RecoveryLifecycleState.RECOVERY_SELECTED ->
                state == RecoveryLifecycleState.ERROR_CLASSIFIED || state == RecoveryLifecycleState.PRIMARY_STARTED || state == RecoveryLifecycleState.PLAYBACK_PREPARED
            RecoveryLifecycleState.RECOVERY_COMMITTED ->
                state == RecoveryLifecycleState.RECOVERY_SELECTED || state == RecoveryLifecycleState.ERROR_CLASSIFIED || state == RecoveryLifecycleState.PRIMARY_STARTED || state == RecoveryLifecycleState.PLAYBACK_PREPARED
            RecoveryLifecycleState.RECOVERY_SUCCESSFUL ->
                state == RecoveryLifecycleState.RECOVERY_COMMITTED || state == RecoveryLifecycleState.PLAYBACK_PREPARED
            RecoveryLifecycleState.RECOVERY_EXHAUSTED -> true
            RecoveryLifecycleState.USER_RETRY_REQUESTED -> true
            RecoveryLifecycleState.SESSION_CANCELLED -> true
        }
        if (allowed) {
            state = next
        }
        return allowed
    }

    fun cancelSession() {
        transitionTo(RecoveryLifecycleState.SESSION_CANCELLED)
    }

    fun markExhausted() {
        transitionTo(RecoveryLifecycleState.RECOVERY_EXHAUSTED)
    }

    fun markPlaybackConfirmed() {
        if (state == RecoveryLifecycleState.RECOVERY_COMMITTED) {
            transitionTo(RecoveryLifecycleState.RECOVERY_SUCCESSFUL)
        }
        transitionTo(RecoveryLifecycleState.PLAYBACK_CONFIRMED)
    }

    fun markUrlAttempted(url: String?): Boolean {
        if (isCancelled()) return false
        val clean = normalizeUrlKey(url)
        if (!isValidHttpOrStreamUrl(clean)) return false
        return attemptedUrls.add(clean)
    }

    fun hasAttemptedUrl(url: String?): Boolean {
        val clean = normalizeUrlKey(url)
        return clean.isNotEmpty() && (attemptedUrls.contains(clean) || attemptedBackupUrls.contains(clean))
    }

    fun attemptedUrlCount(): Int = attemptedUrls.size

    fun recordRebuffer(): Int {
        if (isCancelled()) return rebufferEvents
        rebufferEvents++
        return rebufferEvents
    }

    fun canSwitchEngine(): Boolean = !isCancelled() &&
        !isExhausted() &&
        engineSwitchCount < MAX_ENGINE_SWITCHES

    /**
     * Authoritative, idempotent, single-point recovery action commit.
     * - Exactly 1 committed recovery action = +1 totalRecoveryAttempts.
     * - Duplicate actionId or already-tried backup URL returns false WITHOUT incrementing counters.
     */
    fun commitRecoveryAction(
        actionId: String,
        type: CommittedRecoveryType,
        targetUrl: String = "",
        nowElapsedMs: Long = 0L,
        minCooldownMs: Long = 0L
    ): Boolean {
        if (isCancelled() || isExhausted()) return false
        val cleanId = actionId.trim()
        if (cleanId.isEmpty() || committedActionIds.contains(cleanId)) return false
        if (nowElapsedMs > 0L && minCooldownMs > 0L && lastRecoveryCommitMs > 0L &&
            (nowElapsedMs - lastRecoveryCommitMs) < minCooldownMs
        ) {
            return false
        }

        when (type) {
            CommittedRecoveryType.ENGINE_SWITCH -> {
                if (engineSwitchCount >= MAX_ENGINE_SWITCHES) return false
                engineSwitchCount++
            }
            CommittedRecoveryType.BACKUP_URL -> {
                val cleanUrl = normalizeUrlKey(targetUrl)
                if (!isValidHttpOrStreamUrl(cleanUrl)) return false
                if (attemptedBackupUrls.contains(cleanUrl) || attemptedUrls.contains(cleanUrl)) return false
                attemptedBackupUrls.add(cleanUrl)
                attemptedUrls.add(cleanUrl)
                backupUrlTried = true
            }
            CommittedRecoveryType.RETRY -> {
                retryCount++
            }
            CommittedRecoveryType.WATCHDOG_HEAL -> {
                if (watchdogInterventions >= MAX_WATCHDOG_INTERVENTIONS) return false
                watchdogInterventions++
            }
        }

        committedActionIds.add(cleanId)
        totalRecoveryAttempts++
        if (nowElapsedMs > 0L) {
            lastRecoveryCommitMs = nowElapsedMs
        }
        transitionTo(RecoveryLifecycleState.RECOVERY_COMMITTED)
        return true
    }

    /**
     * Convenience idempotent wrapper for engine switch commit (never double-counts).
     */
    fun markEngineSwitched(actionId: String = "engine_switch_$engineSwitchCount"): Boolean {
        return commitRecoveryAction(actionId = actionId, type = CommittedRecoveryType.ENGINE_SWITCH)
    }

    /**
     * Idempotent backup URL registration:
     * - Validates & normalizes URL before attempting playback
     * - Never double-counts repeated calls for the same URL
     * - Never accepts null/blank/malformed URLs
     */
    fun markBackupUrlTried(backupUrl: String? = ""): Boolean {
        val clean = normalizeUrlKey(backupUrl)
        if (!isValidHttpOrStreamUrl(clean)) return false
        if (attemptedBackupUrls.contains(clean) || attemptedUrls.contains(clean)) {
            backupUrlTried = true
            return false
        }
        return commitRecoveryAction(
            actionId = "backup_url_$clean",
            type = CommittedRecoveryType.BACKUP_URL,
            targetUrl = clean
        )
    }

    /**
     * Pure read-only decision evaluator (checking whether recovery is possible NEVER increments attempt counters!).
     * Callers MUST commit the chosen action via `commitRecoveryAction(...)` when actually executing it.
     */
    fun evaluateDecision(
        decision: StreamErrorDecision,
        hasBackupUrl: Boolean,
        backupUrlCandidate: String = ""
    ): StreamErrorDecision {
        if (isCancelled() || isExhausted()) {
            return decision.copy(
                action = ErrorRecoveryAction.NONE_STOP,
                userMessage = "${decision.userMessage} — Press OK to Retry"
            )
        }

        transitionTo(RecoveryLifecycleState.ERROR_CLASSIFIED)

        val nextConsecutive = if (decision.errorFingerprint == lastErrorFingerprint) {
            consecutiveSameErrorCount + 1
        } else {
            1
        }

        val cleanBackup = normalizeUrlKey(backupUrlCandidate)
        val backupAvailableAndUntried = hasBackupUrl && !backupUrlTried &&
            (cleanBackup.isEmpty() || (isValidHttpOrStreamUrl(cleanBackup) && !hasAttemptedUrl(cleanBackup)))

        if (nextConsecutive > decision.maxRetries && decision.action == ErrorRecoveryAction.RETRY_WITH_COOLDOWN) {
            return if (backupAvailableAndUntried) {
                transitionTo(RecoveryLifecycleState.RECOVERY_SELECTED)
                decision.copy(action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE)
            } else {
                decision.copy(
                    action = ErrorRecoveryAction.NONE_STOP,
                    userMessage = "${decision.userMessage} — Press OK to Retry"
                )
            }
        }

        val chosen = when (decision.action) {
            ErrorRecoveryAction.NONE_STOP -> decision
            ErrorRecoveryAction.SWITCH_ENGINE_ONCE -> {
                if (canSwitchEngine()) {
                    decision
                } else if (backupAvailableAndUntried) {
                    decision.copy(action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE)
                } else {
                    decision.copy(
                        result = ChannelPlaybackResult.UNSUPPORTED,
                        action = ErrorRecoveryAction.NONE_STOP,
                        userMessage = "Unsupported stream on this TV"
                    )
                }
            }
            ErrorRecoveryAction.TRY_BACKUP_URL_ONCE -> {
                if (backupAvailableAndUntried) {
                    decision
                } else {
                    decision.copy(
                        action = ErrorRecoveryAction.NONE_STOP,
                        userMessage = "${decision.userMessage} — Press OK to Retry"
                    )
                }
            }
            ErrorRecoveryAction.RETRY_WITH_COOLDOWN -> {
                if (retryCount < decision.maxRetries && totalRecoveryAttempts < MAX_TOTAL_RECOVERY_ATTEMPTS) {
                    decision
                } else if (backupAvailableAndUntried) {
                    decision.copy(action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE)
                } else {
                    decision.copy(
                        action = ErrorRecoveryAction.NONE_STOP,
                        userMessage = "${decision.userMessage} — Press OK to Retry"
                    )
                }
            }
        }
        if (chosen.action != ErrorRecoveryAction.NONE_STOP) {
            transitionTo(RecoveryLifecycleState.RECOVERY_SELECTED)
        }
        return chosen
    }

    fun recordErrorFingerprint(fingerprint: String) {
        if (fingerprint == lastErrorFingerprint) {
            consecutiveSameErrorCount++
        } else {
            lastErrorFingerprint = fingerprint
            consecutiveSameErrorCount = 1
        }
    }
}

/**
 * RAM PLAYER v23.7 — Smart Channel Intelligence Engine & Unified Cache Policy.
 */
object SmartChannelIntelligenceEngine {

    const val MIN_LIBVLC_CACHE_MS = 650
    const val LOW_RAM_STARTUP_CACHE_MS = 650
    const val STANDARD_STARTUP_CACHE_MS = 800
    const val LOW_RAM_MAX_CACHE_MS = 3000
    const val STANDARD_MAX_CACHE_MS = 4000
    const val REBUFFER_STEP_MS = 750

    fun chooseInitialEngine(
        streamUrl: String,
        globalMode: LiveTvEngineMode,
        rememberedStageOrEngine: String?
    ): LiveTvEngineMode {
        if (globalMode != LiveTvEngineMode.AUTO_OTT_HEAL) {
            return globalMode
        }
        val rem = rememberedStageOrEngine?.trim()?.uppercase(Locale.ROOT).orEmpty()
        when (rem) {
            LiveTvHealStage.VLC_HW_PRIMARY.name,
            LiveTvHealStage.VLC_HW_BACKUP.name,
            LiveTvEngineMode.LIBVLC_HW.id -> return LiveTvEngineMode.LIBVLC_HW
            LiveTvHealStage.VLC_SW_PRIMARY.name,
            LiveTvHealStage.VLC_SW_BACKUP.name,
            LiveTvEngineMode.LIBVLC_SW.id -> return LiveTvEngineMode.LIBVLC_SW
        }

        val lower = streamUrl.trim().lowercase(Locale.ROOT)
        val pathOnly = lower.substringBefore('?')
        if (lower.startsWith("rtmp://") ||
            lower.startsWith("rtmps://") ||
            lower.startsWith("mms://") ||
            lower.startsWith("udp://") ||
            pathOnly.endsWith(".avi") ||
            pathOnly.endsWith(".wmv") ||
            pathOnly.endsWith(".flv") ||
            pathOnly.endsWith(".mpg") ||
            pathOnly.endsWith(".mpeg")
        ) {
            return LiveTvEngineMode.LIBVLC_HW
        }
        return LiveTvEngineMode.AUTO_OTT_HEAL
    }

    fun classifyPlaybackError(
        httpStatusCode: Int,
        errorCodeName: String?,
        message: String?,
        engineMode: LiveTvEngineMode
    ): StreamErrorDecision {
        val codeName = errorCodeName?.trim()?.uppercase(Locale.ROOT).orEmpty()
        val msg = message?.trim()?.lowercase(Locale.ROOT).orEmpty()

        when (httpStatusCode) {
            401, 403 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.UNAVAILABLE,
                action = ErrorRecoveryAction.NONE_STOP,
                maxRetries = 0,
                cooldownMs = 0L,
                userMessage = "Auth / Access Denied (HTTP $httpStatusCode)",
                errorFingerprint = "HTTP_$httpStatusCode"
            )
            404, 410 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.UNAVAILABLE,
                action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE,
                maxRetries = 0,
                cooldownMs = 0L,
                userMessage = "Channel Not Found / Expired (HTTP $httpStatusCode)",
                errorFingerprint = "HTTP_$httpStatusCode"
            )
            429 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 1,
                cooldownMs = 8000L,
                userMessage = "Server Rate Limited (HTTP 429)",
                errorFingerprint = "HTTP_429"
            )
            in 500..599 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 2,
                cooldownMs = 3500L,
                userMessage = "IPTV Server Busy (HTTP $httpStatusCode)",
                errorFingerprint = "HTTP_5XX"
            )
        }

        val isCodecOrContainer = codeName.contains("DECODING") ||
            codeName.contains("DECODER") ||
            codeName.contains("AUDIO_TRACK") ||
            codeName.contains("PARSING_CONTAINER") ||
            codeName.contains("UNSUPPORTED") ||
            msg.contains("mediacodec") ||
            msg.contains("ac3") ||
            msg.contains("eac3") ||
            msg.contains("dts") ||
            msg.contains("audiotrack") ||
            msg.contains("no suitable decoder")

        if (isCodecOrContainer) {
            val canSwitch = engineMode != LiveTvEngineMode.MEDIA3_ONLY
            return StreamErrorDecision(
                result = if (canSwitch) ChannelPlaybackResult.SWITCHING_ENGINE else ChannelPlaybackResult.UNSUPPORTED,
                action = if (canSwitch) ErrorRecoveryAction.SWITCH_ENGINE_ONCE else ErrorRecoveryAction.NONE_STOP,
                maxRetries = 0,
                cooldownMs = 0L,
                userMessage = if (canSwitch) "Switching to OTT-VLC Engine" else "Unsupported Codec on Device",
                errorFingerprint = "CODEC_$codeName"
            )
        }

        if (codeName.contains("PARSING_MANIFEST") || msg.contains("playlist") || msg.contains("malformed")) {
            return StreamErrorDecision(
                result = ChannelPlaybackResult.UNAVAILABLE,
                action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE,
                maxRetries = 1,
                cooldownMs = 1500L,
                userMessage = "Invalid Stream Playlist",
                errorFingerprint = "MANIFEST_INVALID"
            )
        }

        if (msg.contains("unknownhost") || msg.contains("unable to resolve host") || msg.contains("dns")) {
            return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 1,
                cooldownMs = 4000L,
                userMessage = "DNS / Server Host Unreachable",
                errorFingerprint = "DNS_ERROR"
            )
        }

        if (codeName.contains("TIMEOUT") || msg.contains("timeout") || msg.contains("timed out")) {
            return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 2,
                cooldownMs = 3000L,
                userMessage = "Connection Timeout",
                errorFingerprint = "NET_TIMEOUT"
            )
        }

        return StreamErrorDecision(
            result = ChannelPlaybackResult.SERVER_ERROR,
            action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
            maxRetries = 2,
            cooldownMs = 3000L,
            userMessage = "Stream Connection Error",
            errorFingerprint = "IO_$codeName"
        )
    }

    fun computeAdaptiveLibVlcCacheMs(
        isLowRamDevice: Boolean,
        rebufferEventsInSession: Int,
        isDegradedNetwork: Boolean
    ): Int {
        val base = if (isLowRamDevice) LOW_RAM_STARTUP_CACHE_MS else STANDARD_STARTUP_CACHE_MS
        val step = (rebufferEventsInSession.coerceAtLeast(0).coerceAtMost(3)) * REBUFFER_STEP_MS
        val netExtra = if (isDegradedNetwork) REBUFFER_STEP_MS else 0
        val maxCap = if (isLowRamDevice) LOW_RAM_MAX_CACHE_MS else STANDARD_MAX_CACHE_MS
        return (base + step + netExtra).coerceIn(MIN_LIBVLC_CACHE_MS, maxCap)
    }
}
