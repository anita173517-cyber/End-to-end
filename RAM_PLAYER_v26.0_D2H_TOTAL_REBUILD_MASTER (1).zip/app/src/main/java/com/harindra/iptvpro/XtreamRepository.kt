package com.harindra.iptvpro

import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import kotlin.coroutines.coroutineContext

/**
 * StreamX Media3 Pro v18.1 — Next-Generation Ultra Extreme Correct VOD Edition — Xtream Codes Repository.
 *
 * Strict Source-Aware Catalog Separation (Requirement 2B & 3):
 * - Live TV (`get_live_categories` + `get_live_streams`) -> [ContentSourceType.XTREAM_LIVE]
 * - VOD Movies (`get_vod_categories` + `get_vod_streams` + `get_vod_info`) -> [ContentSourceType.XTREAM_VOD_MOVIE]
 * - Series (`get_series_categories` + `get_series` + `get_series_info`) -> [ContentSourceType.XTREAM_SERIES] / [ContentSourceType.XTREAM_SERIES_EPISODE]
 * - Never mixes Live TV channels into Movies or Series, and preserves exact provider category names and IDs.
 */
class XtreamRepository {
    private val fetchMutex = Mutex()

    @Volatile
    private var activeCall: Call? = null

    companion object {
        private const val DEFAULT_MAX_STREAMS = 60_000
        private const val FIRST_BATCH_SIZE = 40
        private const val XTREAM_CALL_TAG = "xtream_api_call"
    }

    fun cancelActiveFetch() {
        runCatching { activeCall?.cancel() }
        activeCall = null
        NetworkClient.cancelCallsWithTag(XTREAM_CALL_TAG)
    }

    fun normalizeServerBaseUrl(rawServerUrl: String): String {
        val cleaned = ProfileStore.sanitizeExternalInput(rawServerUrl).removeSuffix("/")
        if (cleaned.isEmpty()) throw IllegalArgumentException("Server URL is empty")
        return if (cleaned.startsWith("http://", true) || cleaned.startsWith("https://", true)) {
            cleaned
        } else {
            "http://$cleaned"
        }
    }

    private fun apiUrl(
        base: String,
        creds: XtreamCredentials,
        action: String,
        extraParams: Map<String, String> = emptyMap()
    ): String {
        val normalizedBase = normalizeServerBaseUrl(base)
        val parsed = normalizedBase.toHttpUrlOrNull() ?: throw IllegalArgumentException("Invalid Xtream server URL")
        val builder = parsed.newBuilder()
            .addPathSegment("player_api.php")
            .addQueryParameter("username", creds.username.trim())
            .addQueryParameter("password", creds.password.trim())
            .addQueryParameter("action", action)
        for ((k, v) in extraParams) {
            builder.addQueryParameter(k, v)
        }
        return builder.build().toString()
    }

    private fun readStringSafe(reader: JsonReader, default: String = ""): String {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.STRING, JsonToken.NUMBER -> reader.nextString()
            JsonToken.BOOLEAN -> reader.nextBoolean().toString()
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private fun readIntSafe(reader: JsonReader, default: Int): Int {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.NUMBER -> runCatching { reader.nextInt() }.getOrElse {
                runCatching { reader.nextString().toIntOrNull() ?: default }.getOrDefault(default)
            }
            JsonToken.STRING -> reader.nextString().toIntOrNull() ?: default
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private fun readLongSafe(reader: JsonReader, default: Long = 0L): Long {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.NUMBER -> runCatching { reader.nextLong() }.getOrElse {
                runCatching { reader.nextString().toLongOrNull() ?: default }.getOrDefault(default)
            }
            JsonToken.STRING -> reader.nextString().toLongOrNull() ?: default
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private suspend fun fetchCategoriesMap(cleanBase: String, creds: XtreamCredentials, action: String, fallbackLabel: String): Map<String, String> {
        val categoriesMap = LinkedHashMap<String, String>(128)
        val catUrl = apiUrl(cleanBase, creds, action)
        try {
            val req = Request.Builder()
                .url(catUrl)
                .tag(XTREAM_CALL_TAG)
                .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                .build()
            val call = NetworkClient.fastMetaClient.newCall(req)
            activeCall = call
            call.execute().use { res ->
                val body = res.body
                if (res.isSuccessful && body != null) {
                    JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 16384)).use { reader ->
                        if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                            reader.beginArray()
                            while (reader.hasNext()) {
                                coroutineContext.ensureActive()
                                if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                    reader.skipValue()
                                    continue
                                }
                                var catId = ""
                                var catName = fallbackLabel
                                reader.beginObject()
                                while (reader.hasNext()) {
                                    when (reader.nextName()) {
                                        "category_id" -> catId = readStringSafe(reader).trim()
                                        "category_name" -> catName = readStringSafe(reader, fallbackLabel).trim().ifBlank { fallbackLabel }
                                        else -> reader.skipValue()
                                    }
                                }
                                reader.endObject()
                                if (catId.isNotEmpty()) {
                                    categoriesMap[catId] = catName.intern()
                                }
                            }
                            reader.endArray()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            coroutineContext.ensureActive()
            Log.w("StreamX", "Category fetch note ($action): ${e.message}")
        }
        return categoriesMap
    }

    private fun describeHttpFailure(code: Int): String = when (code) {
        401, 403 -> "Invalid Xtream username/password or expired account (HTTP $code)"
        404 -> "Xtream player_api.php endpoint not found on server (HTTP 404)"
        429 -> "Server rate limit reached (HTTP 429) — wait a moment and retry"
        in 500..599 -> "Xtream server temporary overload (HTTP $code)"
        else -> "Server returned HTTP $code"
    }

    /**
     * Builds provider-compatible Live TV primary and backup URLs based on `allowed_output_formats`
     * from `player_api.php` and optional per-profile preference (`auto`, `m3u8`, `ts`).
     */
    fun buildLiveStreamUrls(
        cleanBase: String,
        username: String,
        password: String,
        streamId: String,
        allowedOutputFormats: List<String> = emptyList(),
        preferredExtension: String = "auto"
    ): Pair<String, String> {
        val base = cleanBase.removeSuffix("/")
        val prefix = "$base/live/${username.trim()}/${password.trim()}/"
        val normalizedAllowed = allowedOutputFormats.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val pref = preferredExtension.trim().lowercase()

        val primaryExt = when {
            pref == "ts" -> "ts"
            pref == "m3u8" -> "m3u8"
            normalizedAllowed.isNotEmpty() -> when {
                "m3u8" in normalizedAllowed -> "m3u8"
                "ts" in normalizedAllowed -> "ts"
                else -> normalizedAllowed.first()
            }
            else -> "m3u8"
        }
        val backupExt = when {
            primaryExt == "m3u8" && (normalizedAllowed.isEmpty() || "ts" in normalizedAllowed) -> "ts"
            primaryExt == "ts" && (normalizedAllowed.isEmpty() || "m3u8" in normalizedAllowed) -> "m3u8"
            else -> ""
        }
        val primaryUrl = "$prefix$streamId.$primaryExt"
        val backupUrl = if (backupExt.isNotEmpty()) "$prefix$streamId.$backupExt" else ""
        return primaryUrl to backupUrl
    }

    /**
     * Validates Xtream Codes login & discovers server-supported output formats (`m3u8`, `ts`)
     * plus account expiry status without declaring an account invalid on a single stream failure.
     */
    suspend fun validateAccount(creds: XtreamCredentials): Result<XtreamAccountInfo> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
            val parsed = cleanBase.toHttpUrlOrNull() ?: return@withContext Result.failure(IllegalArgumentException("Invalid Xtream server URL"))
            val authUrl = parsed.newBuilder()
                .addPathSegment("player_api.php")
                .addQueryParameter("username", creds.username.trim())
                .addQueryParameter("password", creds.password.trim())
                .build()
                .toString()
            val req = Request.Builder()
                .url(authUrl)
                .tag(XTREAM_CALL_TAG)
                .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                .build()
            NetworkClient.fastMetaClient.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    return@withContext Result.failure(Exception(describeHttpFailure(res.code)))
                }
                val body = res.body ?: return@withContext Result.failure(Exception("Empty Xtream auth response"))
                var authFlag = 0
                var status = ""
                var expDate = 0L
                var activeCons = 0
                var maxCons = 0
                val formats = ArrayList<String>(4)
                var message = ""

                JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 16384)).use { reader ->
                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                        return@withContext Result.failure(Exception("Non-JSON response from Xtream server"))
                    }
                    reader.beginObject()
                    while (reader.hasNext()) {
                        when (reader.nextName()) {
                            "user_info" -> if (reader.peek() == JsonToken.BEGIN_OBJECT) {
                                reader.beginObject()
                                while (reader.hasNext()) {
                                    when (reader.nextName()) {
                                        "auth" -> authFlag = readIntSafe(reader, 0)
                                        "status" -> status = readStringSafe(reader).trim()
                                        "exp_date" -> expDate = readLongSafe(reader, 0L)
                                        "active_cons" -> activeCons = readIntSafe(reader, 0)
                                        "max_connections" -> maxCons = readIntSafe(reader, 0)
                                        "message" -> message = readStringSafe(reader).trim()
                                        "allowed_output_formats" -> if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                                            reader.beginArray()
                                            while (reader.hasNext()) {
                                                val fmt = readStringSafe(reader).trim().lowercase()
                                                if (fmt.isNotEmpty() && fmt !in formats) formats.add(fmt)
                                            }
                                            reader.endArray()
                                        } else {
                                            reader.skipValue()
                                        }
                                        else -> reader.skipValue()
                                    }
                                }
                                reader.endObject()
                            } else {
                                reader.skipValue()
                            }
                            else -> reader.skipValue()
                        }
                    }
                    reader.endObject()
                }

                val nowEpochSec = System.currentTimeMillis() / 1000L
                val isExpired = status.equals("Expired", ignoreCase = true) ||
                    status.equals("Disabled", ignoreCase = true) ||
                    (expDate > 0L && expDate < nowEpochSec)
                val isAuthed = authFlag == 1 && !isExpired
                val preferredFmt = when {
                    creds.preferredLiveExtension.equals("ts", ignoreCase = true) -> "ts"
                    creds.preferredLiveExtension.equals("m3u8", ignoreCase = true) -> "m3u8"
                    "m3u8" in formats -> "m3u8"
                    "ts" in formats -> "ts"
                    else -> "m3u8"
                }
                Result.success(
                    XtreamAccountInfo(
                        isAuthenticated = isAuthed,
                        status = status.ifBlank { if (authFlag == 1) "Active" else "Unauthorized" },
                        isExpired = isExpired,
                        expDateEpochSec = expDate,
                        activeConnections = activeCons,
                        maxConnections = maxCons,
                        allowedOutputFormats = formats,
                        preferredLiveFormat = preferredFmt,
                        serverMessage = message
                    )
                )
            }
        } catch (e: Exception) {
            coroutineContext.ensureActive()
            Result.failure(e)
        }
    }

    /**
     * Fetches ONLY Live TV streams (`get_live_categories` + `get_live_streams`).
     * Every returned item is tagged with [ContentSourceType.XTREAM_LIVE].
     */
    suspend fun fetchLiveStreams(
        creds: XtreamCredentials,
        maxStreams: Int = DEFAULT_MAX_STREAMS,
        allowedOutputFormats: List<String> = emptyList(),
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)? = null
    ): Result<List<Channel>> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            var lastError: Exception? = null
            for (attempt in 1..2) {
                coroutineContext.ensureActive()
                try {
                    val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                    val categoriesMap = fetchCategoriesMap(cleanBase, creds, "get_live_categories", "Live TV")
                    val streamsUrl = apiUrl(cleanBase, creds, "get_live_streams")
                    val req = Request.Builder()
                        .url(streamsUrl)
                        .tag(XTREAM_CALL_TAG)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    val call = NetworkClient.apiClient.newCall(req)
                    activeCall = call

                    call.execute().use { res ->
                        if (!res.isSuccessful) {
                            val msg = describeHttpFailure(res.code)
                            if ((res.code == 429 || res.code in 500..599) && attempt == 1) {
                                lastError = IOException(msg)
                            } else {
                                return@withLock Result.failure(Exception(msg))
                            }
                        } else {
                            val body = res.body ?: return@withLock Result.failure(Exception("Empty server response"))
                            val list = ArrayList<Channel>(4096)
                            val seenIds = HashSet<String>(4096)
                            val primaryIndexByNormHash = HashMap<Long, Int>(4096)
                            val cleanUser = creds.username.trim()
                            val cleanPass = creds.password.trim()
                            val streamPrefix = "$cleanBase/live/$cleanUser/$cleanPass/"
                            var firstBatchDispatched = false

                            JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536)).use { reader ->
                                if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                                    return@withLock Result.failure(Exception("Invalid Xtream credentials or non-list server response"))
                                }
                                reader.beginArray()
                                var index = 0
                                while (reader.hasNext() && list.size < maxStreams) {
                                    if (index % 1000 == 0) coroutineContext.ensureActive()
                                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                        reader.skipValue()
                                        continue
                                    }
                                    index++
                                    var streamId = ""
                                    var num = index
                                    var name = ""
                                    var catId = ""
                                    var icon = ""
                                    var epgChannelId = ""

                                    reader.beginObject()
                                    while (reader.hasNext()) {
                                        when (reader.nextName()) {
                                            "stream_id" -> streamId = readStringSafe(reader).trim()
                                            "num" -> num = readIntSafe(reader, index)
                                            "name" -> name = readStringSafe(reader).trim()
                                            "category_id" -> catId = readStringSafe(reader).trim()
                                            "stream_icon" -> icon = readStringSafe(reader).trim()
                                            "epg_channel_id" -> epgChannelId = readStringSafe(reader).trim()
                                            else -> reader.skipValue()
                                        }
                                    }
                                    reader.endObject()

                                    if (streamId.isNotEmpty() && seenIds.add(streamId)) {
                                        val resolvedCategory = categoriesMap[catId] ?: "Live TV"
                                        val resolvedName = name.ifBlank { "Channel ${list.size + 1}" }
                                        val (candidateUrl, tsFallbackUrl) = buildLiveStreamUrls(
                                            cleanBase = cleanBase,
                                            username = cleanUser,
                                            password = cleanPass,
                                            streamId = streamId,
                                            allowedOutputFormats = allowedOutputFormats,
                                            preferredExtension = creds.preferredLiveExtension
                                        )
                                        val normHash = M3uParser.fnv1a64NormalizedPair(resolvedCategory, resolvedName)
                                        val existingIdx = primaryIndexByNormHash[normHash]
                                        if (existingIdx != null && existingIdx in list.indices) {
                                            val primary = list[existingIdx]
                                            if (primary.backupUrl.isBlank() || primary.backupUrl.endsWith(".ts", ignoreCase = true)) {
                                                list[existingIdx] = primary.copy(backupUrl = tsFallbackUrl)
                                            }
                                        } else {
                                            val resolvedNum = if (num > 0) num else list.size + 1
                                            val newIdx = list.size
                                            list.add(
                                                Channel(
                                                    id = streamId,
                                                    number = resolvedNum,
                                                    name = resolvedName,
                                                    category = resolvedCategory,
                                                    streamUrl = candidateUrl,
                                                    logoUrl = icon,
                                                    epgId = epgChannelId,
                                                    backupUrl = tsFallbackUrl,
                                                    sourceType = ContentSourceType.XTREAM_LIVE,
                                                    categoryId = catId
                                                )
                                            )
                                            primaryIndexByNormHash.putIfAbsent(normHash, newIdx)
                                            if (!firstBatchDispatched && list.size == FIRST_BATCH_SIZE && onFirstBatchReady != null) {
                                                firstBatchDispatched = true
                                                onFirstBatchReady.invoke(ArrayList(list))
                                            }
                                        }
                                    }
                                }
                                while (reader.hasNext()) {
                                    reader.skipValue()
                                }
                                reader.endArray()
                            }
                            activeCall = null
                            return@withLock Result.success(list)
                        }
                    }
                } catch (e: Exception) {
                    coroutineContext.ensureActive()
                    lastError = e
                    Log.w("StreamX", "Xtream fetchLiveStreams attempt $attempt warning: ${e.message}")
                    if (e is IllegalArgumentException) return@withLock Result.failure(e)
                    if (attempt == 1) {
                        delay(650L)
                    }
                } finally {
                    activeCall = null
                }
            }
            Result.failure(lastError ?: Exception("Failed to load Xtream channels"))
        }
    }

    /**
     * Fetches ONLY VOD Movies from the Xtream Codes server (`get_vod_categories` + `get_vod_streams`).
     * Preserves the provider's exact category names (without artificial prefixes) and tags every entry
     * with [ContentSourceType.XTREAM_VOD_MOVIE].
     */
    suspend fun fetchVodStreams(
        creds: XtreamCredentials,
        maxStreams: Int = 25_000,
        startingNumber: Int = 1
    ): Result<List<Channel>> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            var lastError: Exception? = null
            for (attempt in 1..2) {
                coroutineContext.ensureActive()
                try {
                    val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                    val categoriesMap = fetchCategoriesMap(cleanBase, creds, "get_vod_categories", "Movies")
                    val vodUrl = apiUrl(cleanBase, creds, "get_vod_streams")
                    val req = Request.Builder()
                        .url(vodUrl)
                        .tag(XTREAM_CALL_TAG)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    val call = NetworkClient.apiClient.newCall(req)
                    activeCall = call
                    call.execute().use { res ->
                        if (!res.isSuccessful) {
                            val message = describeHttpFailure(res.code)
                            if ((res.code == 429 || res.code in 500..599) && attempt == 1) {
                                lastError = IOException(message)
                            } else {
                                return@withLock Result.failure(Exception(message))
                            }
                        } else {
                            val body = res.body ?: return@withLock Result.failure(Exception("Empty VOD response"))
                            val list = ArrayList<Channel>(2048)
                            val cleanUser = creds.username.trim()
                            val cleanPass = creds.password.trim()
                            val moviePrefix = "$cleanBase/movie/$cleanUser/$cleanPass/"

                            JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536)).use { reader ->
                                if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                                    return@withLock Result.success(emptyList())
                                }
                                reader.beginArray()
                                var index = 0
                                while (reader.hasNext() && list.size < maxStreams) {
                                    if (index % 1000 == 0) coroutineContext.ensureActive()
                                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                        reader.skipValue()
                                        continue
                                    }
                                    index++
                                    var streamId = ""
                                    var name = ""
                                    var catId = ""
                                    var icon = ""
                                    var ext = "mp4"
                                    var rating = ""
                                    var addedTs = 0L
                                    var trailer = ""
                                    var releaseDate = ""

                                    reader.beginObject()
                                    while (reader.hasNext()) {
                                        when (reader.nextName()) {
                                            "stream_id" -> streamId = readStringSafe(reader).trim()
                                            "name" -> name = readStringSafe(reader).trim()
                                            "category_id" -> catId = readStringSafe(reader).trim()
                                            "stream_icon" -> icon = readStringSafe(reader).trim()
                                            "container_extension" -> ext = readStringSafe(reader, "mp4").trim().ifBlank { "mp4" }
                                            "rating" -> rating = readStringSafe(reader).trim()
                                            "added" -> addedTs = readLongSafe(reader, 0L)
                                            "youtube_trailer", "trailer" -> trailer = readStringSafe(reader).trim()
                                            "releaseDate", "release_date", "year" -> releaseDate = readStringSafe(reader).trim()
                                            else -> reader.skipValue()
                                        }
                                    }
                                    reader.endObject()

                                    if (streamId.isNotEmpty()) {
                                        val safeExtension = ext.removePrefix(".").take(12).filter { it.isLetterOrDigit() }.ifBlank { "mp4" }
                                        val vodCat = categoriesMap[catId] ?: "Movies"
                                        list.add(
                                            Channel(
                                                id = "vod_$streamId",
                                                number = startingNumber + list.size,
                                                name = name.ifBlank { "Movie ${list.size + 1}" },
                                                category = vodCat,
                                                streamUrl = "$moviePrefix$streamId.$safeExtension",
                                                logoUrl = icon,
                                                sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
                                                categoryId = catId,
                                                containerExtension = safeExtension,
                                                releaseDate = releaseDate,
                                                rating = rating.takeIf { it != "0" && it != "0.0" }.orEmpty(),
                                                trailerUrl = normalizeTrailerUrl(trailer),
                                                addedTimestamp = if (addedTs > 0L) addedTs else index.toLong()
                                            )
                                        )
                                    }
                                }
                                while (reader.hasNext()) reader.skipValue()
                                reader.endArray()
                            }
                            return@withLock Result.success(list)
                        }
                    }
                } catch (e: Exception) {
                    coroutineContext.ensureActive()
                    lastError = e
                    Log.w("StreamX", "Xtream fetchVodStreams attempt $attempt warning: ${e.message}")
                    if (e is IllegalArgumentException) return@withLock Result.failure(e)
                } finally {
                    activeCall = null
                }
                if (attempt == 1) delay(650L)
            }
            Result.failure(lastError ?: Exception("Failed to load Xtream VOD movies"))
        }
    }

    /**
     * Fetches detailed movie metadata from Xtream `get_vod_info&vod_id=<id>`.
     * Never invents plot, cast, rating, or trailer URLs; returns only what the provider supplies.
     */
    suspend fun fetchVodMovieInfo(
        creds: XtreamCredentials,
        vodChannel: Channel
    ): Result<VodMovieDetailInfo> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            val rawVodId = vodChannel.id.removePrefix("vod_").trim()
            try {
                val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                val infoUrl = apiUrl(cleanBase, creds, "get_vod_info", mapOf("vod_id" to rawVodId))
                val req = Request.Builder()
                    .url(infoUrl)
                    .tag(XTREAM_CALL_TAG)
                    .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                    .build()
                val call = NetworkClient.fastMetaClient.newCall(req)
                activeCall = call
                call.execute().use { res ->
                    if (!res.isSuccessful) {
                        return@withLock Result.failure(Exception(describeHttpFailure(res.code)))
                    }
                    val body = res.body ?: return@withLock Result.failure(Exception("Empty VOD info"))
                    var title = vodChannel.cleanMovieDisplayTitle()
                    var poster = vodChannel.logoUrl
                    var backdrop = ""
                    var releaseDate = vodChannel.releaseDate
                    var rating = vodChannel.rating
                    var genre = vodChannel.category
                    var plot = vodChannel.plot
                    var cast = vodChannel.cast
                    var director = vodChannel.director
                    var duration = vodChannel.durationLabel
                    var ext = vodChannel.containerExtension.ifBlank { "mp4" }
                    var trailer = vodChannel.trailerUrl

                    JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 16384)).use { reader ->
                        if (reader.peek() == JsonToken.BEGIN_OBJECT) {
                            reader.beginObject()
                            while (reader.hasNext()) {
                                when (reader.nextName()) {
                                    "info" -> if (reader.peek() == JsonToken.BEGIN_OBJECT) {
                                        reader.beginObject()
                                        while (reader.hasNext()) {
                                            when (reader.nextName()) {
                                                "name", "o_name" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) title = v
                                                }
                                                "movie_image", "cover_big" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) poster = v
                                                }
                                                "backdrop_path" -> {
                                                    if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                                                        reader.beginArray()
                                                        while (reader.hasNext()) {
                                                            val b = readStringSafe(reader).trim()
                                                            if (backdrop.isEmpty() && b.isNotBlank()) backdrop = b
                                                        }
                                                        reader.endArray()
                                                    } else {
                                                        val b = readStringSafe(reader).trim()
                                                        if (b.isNotBlank()) backdrop = b
                                                    }
                                                }
                                                "releasedate", "release_date", "year" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) releaseDate = v
                                                }
                                                "rating" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank() && v != "0" && v != "0.0") rating = v
                                                }
                                                "genre" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) genre = v
                                                }
                                                "plot", "description" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) plot = v
                                                }
                                                "cast", "actors" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) cast = v
                                                }
                                                "director" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) director = v
                                                }
                                                "duration" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank() && v != "00:00:00") duration = v
                                                }
                                                "youtube_trailer", "trailer" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) trailer = normalizeTrailerUrl(v)
                                                }
                                                else -> reader.skipValue()
                                            }
                                        }
                                        reader.endObject()
                                    } else {
                                        reader.skipValue()
                                    }
                                    "movie_data" -> if (reader.peek() == JsonToken.BEGIN_OBJECT) {
                                        reader.beginObject()
                                        while (reader.hasNext()) {
                                            when (reader.nextName()) {
                                                "container_extension" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank()) ext = v
                                                }
                                                "name" -> {
                                                    val v = readStringSafe(reader).trim()
                                                    if (v.isNotBlank() && title.isBlank()) title = v
                                                }
                                                else -> reader.skipValue()
                                            }
                                        }
                                        reader.endObject()
                                    } else {
                                        reader.skipValue()
                                    }
                                    else -> reader.skipValue()
                                }
                            }
                            reader.endObject()
                        }
                    }

                    Result.success(
                        VodMovieDetailInfo(
                            streamId = rawVodId,
                            title = title,
                            posterUrl = poster,
                            backdropUrl = backdrop,
                            releaseDate = releaseDate,
                            rating = rating,
                            genre = genre,
                            plot = plot,
                            cast = cast,
                            director = director,
                            durationLabel = duration,
                            containerExtension = ext,
                            trailerUrl = trailer
                        )
                    )
                }
            } catch (e: Exception) {
                coroutineContext.ensureActive()
                Result.failure(e)
            } finally {
                activeCall = null
            }
        }
    }

    fun normalizeTrailerUrl(rawTrailer: String): String {
        val trimmed = rawTrailer.trim()
        if (trimmed.isEmpty()) return ""
        if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
            return trimmed
        }
        // Xtream servers often provide an 11-character YouTube video ID in `youtube_trailer`
        if (trimmed.length in 8..16 && trimmed.all { it.isLetterOrDigit() || it == '_' || it == '-' }) {
            return "https://www.youtube.com/watch?v=$trimmed"
        }
        return ""
    }

    /**
     * Fetches ONLY Series catalog entries from Xtream (`get_series_categories` + `get_series`).
     * Tags every entry with [ContentSourceType.XTREAM_SERIES] and preserves exact provider category names.
     */
    suspend fun fetchSeriesCatalog(
        creds: XtreamCredentials,
        maxSeries: Int = 15_000,
        startingNumber: Int = 1
    ): Result<List<Channel>> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            var lastError: Exception? = null
            for (attempt in 1..2) {
                coroutineContext.ensureActive()
                try {
                    val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                    val categoriesMap = fetchCategoriesMap(cleanBase, creds, "get_series_categories", "Series")
                    val seriesUrl = apiUrl(cleanBase, creds, "get_series")
                    val req = Request.Builder()
                        .url(seriesUrl)
                        .tag(XTREAM_CALL_TAG)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    val call = NetworkClient.apiClient.newCall(req)
                    activeCall = call
                    call.execute().use { res ->
                        if (!res.isSuccessful) {
                            val message = describeHttpFailure(res.code)
                            if ((res.code == 429 || res.code in 500..599) && attempt == 1) {
                                lastError = IOException(message)
                            } else {
                                return@withLock Result.failure(Exception(message))
                            }
                        } else {
                            val body = res.body ?: return@withLock Result.failure(Exception("Empty Series response"))
                            val list = ArrayList<Channel>(1024)

                            JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536)).use { reader ->
                                if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                                    return@withLock Result.success(emptyList())
                                }
                                reader.beginArray()
                                var index = 0
                                while (reader.hasNext() && list.size < maxSeries) {
                                    if (index % 1000 == 0) coroutineContext.ensureActive()
                                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                        reader.skipValue()
                                        continue
                                    }
                                    index++
                                    var seriesId = ""
                                    var name = ""
                                    var catId = ""
                                    var cover = ""
                                    var plot = ""
                                    var cast = ""
                                    var director = ""
                                    var genre = ""
                                    var releaseDate = ""
                                    var rating = ""
                                    var lastModified = 0L

                                    reader.beginObject()
                                    while (reader.hasNext()) {
                                        when (reader.nextName()) {
                                            "series_id" -> seriesId = readStringSafe(reader).trim()
                                            "name" -> name = readStringSafe(reader).trim()
                                            "category_id" -> catId = readStringSafe(reader).trim()
                                            "cover" -> cover = readStringSafe(reader).trim()
                                            "plot" -> plot = readStringSafe(reader).trim().take(320)
                                            "cast" -> cast = readStringSafe(reader).trim().take(220)
                                            "director" -> director = readStringSafe(reader).trim().take(120)
                                            "genre" -> genre = readStringSafe(reader).trim()
                                            "releaseDate", "release_date", "year" -> releaseDate = readStringSafe(reader).trim()
                                            "rating" -> rating = readStringSafe(reader).trim()
                                            "last_modified" -> lastModified = readLongSafe(reader, 0L)
                                            else -> reader.skipValue()
                                        }
                                    }
                                    reader.endObject()

                                    if (seriesId.isNotEmpty()) {
                                        val serCat = categoriesMap[catId] ?: genre.ifBlank { "Series" }
                                        list.add(
                                            Channel(
                                                id = "series_$seriesId",
                                                number = startingNumber + list.size,
                                                name = name.ifBlank { "Series ${list.size + 1}" },
                                                category = serCat,
                                                streamUrl = "xtream://series/$seriesId",
                                                logoUrl = cover,
                                                epgId = plot,
                                                sourceType = ContentSourceType.XTREAM_SERIES,
                                                categoryId = catId,
                                                releaseDate = releaseDate,
                                                rating = rating.takeIf { it != "0" && it != "0.0" }.orEmpty(),
                                                plot = plot,
                                                cast = cast,
                                                director = director,
                                                addedTimestamp = if (lastModified > 0L) lastModified else index.toLong(),
                                                seriesId = seriesId
                                            )
                                        )
                                    }
                                }
                                while (reader.hasNext()) reader.skipValue()
                                reader.endArray()
                            }
                            return@withLock Result.success(list)
                        }
                    }
                } catch (e: Exception) {
                    coroutineContext.ensureActive()
                    lastError = e
                    Log.w("StreamX", "Xtream fetchSeriesCatalog attempt $attempt warning: ${e.message}")
                    if (e is IllegalArgumentException) return@withLock Result.failure(e)
                } finally {
                    activeCall = null
                }
                if (attempt == 1) delay(650L)
            }
            Result.failure(lastError ?: Exception("Failed to load Xtream Series catalog"))
        }
    }

    /**
     * Fetches real seasons and episodes for a specific Xtream `series_id` via `get_series_info`.
     * Never fabricates seasons or episodes; only returns actual episodes provided by the server,
     * tagged with [ContentSourceType.XTREAM_SERIES_EPISODE].
     */
    suspend fun fetchSeriesEpisodes(
        creds: XtreamCredentials,
        seriesId: String,
        seriesTitle: String,
        seriesCategory: String,
        fallbackCover: String
    ): Result<List<SeriesEpisodeItem>> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            val cleanSeriesId = seriesId.removePrefix("series_").trim()
            try {
                val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                val infoUrl = apiUrl(
                    cleanBase,
                    creds,
                    "get_series_info",
                    mapOf("series_id" to cleanSeriesId)
                )
                val req = Request.Builder()
                    .url(infoUrl)
                    .tag(XTREAM_CALL_TAG)
                    .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                    .build()
                val call = NetworkClient.apiClient.newCall(req)
                activeCall = call
                call.execute().use { res ->
                    if (!res.isSuccessful) {
                        return@withLock Result.failure(Exception(describeHttpFailure(res.code)))
                    }
                    val body = res.body ?: return@withLock Result.failure(Exception("Empty series info"))
                    val episodes = ArrayList<SeriesEpisodeItem>(64)
                    val cleanUser = creds.username.trim()
                    val cleanPass = creds.password.trim()
                    val episodePrefix = "$cleanBase/series/$cleanUser/$cleanPass/"

                    JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768)).use { reader ->
                        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                            return@withLock Result.success(emptyList())
                        }
                        reader.beginObject()
                        while (reader.hasNext()) {
                            when (reader.nextName()) {
                                "episodes" -> {
                                    when (reader.peek()) {
                                        JsonToken.BEGIN_OBJECT -> {
                                            reader.beginObject()
                                            while (reader.hasNext()) {
                                                val seasonKey = reader.nextName()
                                                val parsedSeason = seasonKey.toIntOrNull()?.coerceAtLeast(1) ?: 1
                                                parseEpisodeArray(
                                                    reader = reader,
                                                    defaultSeason = parsedSeason,
                                                    seriesId = cleanSeriesId,
                                                    seriesTitle = seriesTitle,
                                                    seriesCategory = seriesCategory,
                                                    fallbackCover = fallbackCover,
                                                    episodePrefix = episodePrefix,
                                                    outList = episodes
                                                )
                                            }
                                            reader.endObject()
                                        }
                                        JsonToken.BEGIN_ARRAY -> {
                                            reader.beginArray()
                                            var sIdx = 1
                                            while (reader.hasNext()) {
                                                parseEpisodeArray(
                                                    reader = reader,
                                                    defaultSeason = sIdx,
                                                    seriesId = cleanSeriesId,
                                                    seriesTitle = seriesTitle,
                                                    seriesCategory = seriesCategory,
                                                    fallbackCover = fallbackCover,
                                                    episodePrefix = episodePrefix,
                                                    outList = episodes
                                                )
                                                sIdx++
                                            }
                                            reader.endArray()
                                        }
                                        else -> reader.skipValue()
                                    }
                                }
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()
                    }
                    Result.success(episodes)
                }
            } catch (e: Exception) {
                coroutineContext.ensureActive()
                Result.failure(e)
            } finally {
                activeCall = null
            }
        }
    }

    private fun parseEpisodeArray(
        reader: JsonReader,
        defaultSeason: Int,
        seriesId: String,
        seriesTitle: String,
        seriesCategory: String,
        fallbackCover: String,
        episodePrefix: String,
        outList: MutableList<SeriesEpisodeItem>
    ) {
        if (reader.peek() != JsonToken.BEGIN_ARRAY) {
            reader.skipValue()
            return
        }
        reader.beginArray()
        var epIdx = 0
        while (reader.hasNext()) {
            if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                reader.skipValue()
                continue
            }
            epIdx++
            var epId = ""
            var epNum = epIdx
            var seasonNum = defaultSeason
            var title = ""
            var ext = "mp4"
            var thumb = fallbackCover
            var duration = ""
            var plot = ""
            var releaseDate = ""

            reader.beginObject()
            while (reader.hasNext()) {
                when (reader.nextName()) {
                    "id" -> epId = readStringSafe(reader).trim()
                    "episode_num" -> epNum = readIntSafe(reader, epIdx)
                    "season" -> seasonNum = readIntSafe(reader, defaultSeason)
                    "title" -> title = readStringSafe(reader).trim()
                    "container_extension" -> ext = readStringSafe(reader, "mp4").trim().ifBlank { "mp4" }
                    "info" -> {
                        if (reader.peek() == JsonToken.BEGIN_OBJECT) {
                            reader.beginObject()
                            while (reader.hasNext()) {
                                when (reader.nextName()) {
                                    "movie_image" -> {
                                        val img = readStringSafe(reader).trim()
                                        if (img.isNotBlank()) thumb = img
                                    }
                                    "duration" -> duration = readStringSafe(reader).trim()
                                    "plot" -> plot = readStringSafe(reader).trim().take(240)
                                    "releasedate", "release_date" -> releaseDate = readStringSafe(reader).trim()
                                    else -> reader.skipValue()
                                }
                            }
                            reader.endObject()
                        } else {
                            reader.skipValue()
                        }
                    }
                    else -> reader.skipValue()
                }
            }
            reader.endObject()

            if (epId.isNotEmpty()) {
                val safeExt = ext.removePrefix(".").take(12).filter { it.isLetterOrDigit() }.ifBlank { "mp4" }
                val streamUrl = "$episodePrefix$epId.$safeExt"
                val sPad = seasonNum.coerceAtLeast(1).toString().padStart(2, '0')
                val ePad = epNum.coerceAtLeast(1).toString().padStart(2, '0')
                val epDisplayTitle = title.ifBlank {
                    "$seriesTitle - S${sPad}E${ePad}"
                }
                val ch = Channel(
                    id = "ep_${seriesId}_$epId",
                    number = epNum,
                    name = epDisplayTitle,
                    category = seriesCategory,
                    streamUrl = streamUrl,
                    logoUrl = thumb,
                    sourceType = ContentSourceType.XTREAM_SERIES_EPISODE,
                    containerExtension = safeExt,
                    releaseDate = releaseDate,
                    plot = plot,
                    durationLabel = duration,
                    seriesId = seriesId
                )
                outList.add(
                    SeriesEpisodeItem(
                        globalChannelIndex = -1,
                        channel = ch,
                        seriesId = seriesId,
                        seriesTitle = seriesTitle,
                        seasonNumber = seasonNum.coerceAtLeast(1),
                        episodeNumber = epNum.coerceAtLeast(1),
                        episodeTitle = epDisplayTitle,
                        durationLabel = duration,
                        plot = plot,
                        releaseDate = releaseDate
                    )
                )
            }
        }
        reader.endArray()
    }
}
