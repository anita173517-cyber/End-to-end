package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v23.6 — Regression & Recovery Lifecycle Unit Tests.
 * Covers:
 * - Recovery session persistence across primary -> backup -> engine fallback
 * - Backup URL attempted at most once and never retried repeatedly
 * - Hard recovery ceiling (MAX_TOTAL_RECOVERY_ATTEMPTS)
 * - Unified 1500ms..3300ms (512MB TV) / 1800ms..4200ms (standard) cache policy consistency
 * - Audio codec fallback decisions (AC3/E-AC3/DTS vs AAC)
 */
class PlaybackRecoveryV236Test {

    @Test
    fun backupUrlIsAttemptedAtMostOnceAndSessionStatePersists() {
        val session = BoundedRecoverySession(sessionToken = 101L, channelKey = "sony_max_hd")
        val primary = "http://xtream.example:8080/live/u/p/343.m3u8"
        val backup = "http://xtream.example:8080/live/u/p/343.ts"

        assertTrue(session.markUrlAttempted(primary))
        assertFalse("Primary URL must not be marked fresh twice", session.markUrlAttempted(primary))

        val err404 = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 404,
            errorCodeName = "ERROR_CODE_IO_BAD_HTTP_STATUS",
            message = "HTTP 404",
            engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
        )
        val d1 = session.evaluateDecision(err404, hasBackupUrl = true, backupUrlCandidate = backup)
        assertEquals(ErrorRecoveryAction.TRY_BACKUP_URL_ONCE, d1.action)

        // Mark backup attempted BEFORE starting backup playback (session NOT reset!)
        session.markBackupUrlTried(backup)
        assertTrue(session.backupUrlTried)
        assertTrue(session.hasAttemptedUrl(backup))
        assertEquals(2, session.attemptedUrlCount())

        // If backup URL also fails, same session MUST stop immediately (zero repeat loop!)
        val d2 = session.evaluateDecision(err404, hasBackupUrl = true, backupUrlCandidate = backup)
        assertEquals(ErrorRecoveryAction.NONE_STOP, d2.action)
    }

    @Test
    fun totalRecoveryAttemptsNeverExceedHardCeiling() {
        val session = BoundedRecoverySession(sessionToken = 102L, channelKey = "star_gold_hd")
        val err503 = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 503,
            errorCodeName = "ERROR_CODE_IO_BAD_HTTP_STATUS",
            message = "Service Unavailable",
            engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
        )
        val a1 = session.evaluateDecision(err503, hasBackupUrl = true, backupUrlCandidate = "http://x/1.ts")
        assertEquals(ErrorRecoveryAction.RETRY_WITH_COOLDOWN, a1.action)
        session.recordErrorFingerprint(err503.errorFingerprint)
        assertTrue(session.commitRecoveryAction("r1", CommittedRecoveryType.RETRY))

        val a2 = session.evaluateDecision(err503, hasBackupUrl = true, backupUrlCandidate = "http://x/1.ts")
        assertEquals(ErrorRecoveryAction.RETRY_WITH_COOLDOWN, a2.action)
        session.recordErrorFingerprint(err503.errorFingerprint)
        assertTrue(session.commitRecoveryAction("r2", CommittedRecoveryType.RETRY))

        val a3 = session.evaluateDecision(err503, hasBackupUrl = true, backupUrlCandidate = "http://x/1.ts")
        assertEquals(ErrorRecoveryAction.TRY_BACKUP_URL_ONCE, a3.action)
        assertTrue(session.markBackupUrlTried("http://x/1.ts"))

        assertEquals(BoundedRecoverySession.MAX_TOTAL_RECOVERY_ATTEMPTS, session.totalRecoveryAttempts)
        val a4 = session.evaluateDecision(err503, hasBackupUrl = true, backupUrlCandidate = "http://x/2.ts")
        assertEquals(ErrorRecoveryAction.NONE_STOP, a4.action)
    }

    @Test
    fun unifiedCachePolicyHasZeroEngineOverrideMismatch() {
        for (lowRam in listOf(true, false)) {
            for (rebuffers in 0..5) {
                for (degraded in listOf(true, false)) {
                    val computed = SmartChannelIntelligenceEngine.computeAdaptiveLibVlcCacheMs(
                        isLowRamDevice = lowRam,
                        rebufferEventsInSession = rebuffers,
                        isDegradedNetwork = degraded
                    )
                    val maxAllowed = if (lowRam) {
                        SmartChannelIntelligenceEngine.LOW_RAM_MAX_CACHE_MS
                    } else {
                        SmartChannelIntelligenceEngine.STANDARD_MAX_CACHE_MS
                    }
                    assertTrue(
                        "Computed cache $computed must be >= MIN_LIBVLC_CACHE_MS (${SmartChannelIntelligenceEngine.MIN_LIBVLC_CACHE_MS})",
                        computed >= SmartChannelIntelligenceEngine.MIN_LIBVLC_CACHE_MS
                    )
                    assertTrue(
                        "Computed cache $computed must be <= maxAllowed ($maxAllowed)",
                        computed <= maxAllowed
                    )
                }
            }
        }
    }

    @Test
    fun audioFallbackDecisionsRespectCodecAndEngineMode() {
        assertTrue(
            LiveTvEngineRouter.shouldProactivelySwitchToLibVlc(
                hasUnsupportedVideoTrack = false,
                hasUnsupportedAudioTrack = false,
                audioMimeType = "audio/ac3",
                audioCodecs = "ac-3",
                audioChannelCount = 6,
                audioDecoderError = null,
                audioOutputError = null,
                engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
            )
        )
        assertFalse(
            LiveTvEngineRouter.shouldProactivelySwitchToLibVlc(
                hasUnsupportedVideoTrack = false,
                hasUnsupportedAudioTrack = false,
                audioMimeType = "audio/mp4a-latm",
                audioCodecs = "mp4a.40.2",
                audioChannelCount = 2,
                audioDecoderError = null,
                audioOutputError = null,
                engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
            )
        )
    }
}
