package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for RAM PLAYER v26.0 Smart RAM Profile & 3D Animation Engine (Section 13).
 */
class D2hRebuildAndRamProfileV260Test {

    @Test
    fun recommendedRamProfileMatchesDeviceRamTiers() {
        assertEquals(RamProfileMode.RAM_512MB_ULTRA_LITE, RamProfileMode.recommendedForRamMb(512L))
        assertEquals(RamProfileMode.RAM_1GB_LITE, RamProfileMode.recommendedForRamMb(1024L))
        assertEquals(RamProfileMode.RAM_2GB_BALANCED, RamProfileMode.recommendedForRamMb(2048L))
        assertEquals(RamProfileMode.RAM_4GB_ULTRA_3D, RamProfileMode.recommendedForRamMb(4096L))
        assertEquals(RamProfileMode.RAM_4GB_ULTRA_3D, RamProfileMode.recommendedForRamMb(8192L))
    }

    @Test
    fun ultraLite512MbDisablesHeavyAnimationsAnd3dTilt() {
        val m = RamProfileMode.RAM_512MB_ULTRA_LITE
        assertEquals(0L, m.animationDurationMs)
        assertFalse(m.enable3dTilt)
        assertFalse(m.enableGlassDepth)
        assertEquals(1.0f, m.focusScale, 0.001f)
    }

    @Test
    fun ultra3d4GbEnablesPerspectiveTiltAndGlassDepth() {
        val m = RamProfileMode.RAM_4GB_ULTRA_3D
        assertTrue(m.animationDurationMs >= 180L)
        assertTrue(m.enable3dTilt)
        assertTrue(m.enableGlassDepth)
        assertTrue(m.focusScale > 1.05f)
    }

    @Test
    fun fromIdResolvesAllFourProfilesCaseInsensitively() {
        assertEquals(RamProfileMode.RAM_512MB_ULTRA_LITE, RamProfileMode.fromId("ram_512mb"))
        assertEquals(RamProfileMode.RAM_1GB_LITE, RamProfileMode.fromId("RAM_1GB"))
        assertEquals(RamProfileMode.RAM_2GB_BALANCED, RamProfileMode.fromId("RAM_2GB"))
        assertEquals(RamProfileMode.RAM_4GB_ULTRA_3D, RamProfileMode.fromId("RAM_4GB_3D"))
        assertEquals(null, RamProfileMode.fromId("UNKNOWN"))
    }
}
